///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.tma.view;
//
//import com.tma.model.Battery;
//import com.tma.model.Display;
//import com.tma.model.GSM;
//import com.tma.model.EnumShare.batteryType;
//
//import java.io.IOException;
//import java.util.Scanner;
//
///**
// *
// * @author pduonghoa
// */
//public class main {
//    public static void main(String[] args) throws IOException{
//        System.out.println("PROGRAM RUNNING...\n");
//        Scanner in = new Scanner(System.in); 
//        
//        //add display
//        Display dis = new Display(10, 10000);
//        System.out.println(dis.toString());
//        System.out.println("=========================\n");
//        
//        //add battery
//        Battery bat = new Battery("bat_1", 10, 5, batteryType.LiIon);
//        System.out.println(bat);
//        System.out.println("=========================\n");
//        
//        //add GSM
//        GSM mobile = new GSM("mobile-1", "samsum", (float)256831.23, "hoa", bat, dis);
//
//        System.out.println(mobile);
//
//
//        System.out.println("\nPROGRAM END!!!");
//
//    }
//    public void checkingCall(){
//int menu = 0;
//
//    }
//
//    public void modifGSM(){
//    }
//}


import com.tma.controller.GSMController;
import com.tma.controller.MainController;
import com.tma.utils.*;
import com.tma.utils.EnumShare.batteryType;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class main {

    static List<GSM> gsm = new ArrayList();
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException{
        String url = "src/main/java/input/input.txt";

        InputStream is = new FileInputStream(url);

        // Create a temporary byte array.
        byte[] tempByteArray = new byte[50];
        int byteCount = -1;
        System.out.println(tempByteArray);
        System.out.println(tempByteArray.length);
        int nth = 0;
        while ((byteCount = is.read(tempByteArray)) != -1) {
            nth++;
            System.out.println("--- Read th: " + nth + " ---");
            System.out.println(" >> Number of bytes read: " + byteCount +"\n");

            for(int i= 0; i < byteCount; i++) {
                int code = tempByteArray[i] & 0xff;

                System.out.println(tempByteArray[i] + "    " + code + "    " + (char)code);
            }
        }
        is.close();
        autoAddGSM();
        MainController.mainmenu(gsm);
    }
    public static void autoAddGSM() throws IOException {
        Battery bat1 = new Battery("model-1", 100, 200, batteryType.LiIon);
        Battery bat2 = new Battery("model-2", 100, 200, batteryType.NiMH);
        Battery bat3 = new Battery("model-3", 100, 200, batteryType.NiMH);

        Display dis1 = new Display(10, 200);
        Display dis2 = new Display(30, 313);
        Display dis3 = new Display(40, 400);

        gsm.add(GSMController.addGSM("galaxy", "samsum", 200000, "gasam", bat1, dis1));
        gsm.add(GSMController.addGSM("iphone x", "apple", 1600000, "steve", bat2, dis3));
        gsm.add(GSMController.addGSM("iphone y", "apple", 5000000, "job", bat3, dis3));
    }
}

