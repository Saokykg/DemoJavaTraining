/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tma.controller;

import com.tma.utils.Battery;
import com.tma.utils.Call;
import com.tma.utils.Display;
import com.tma.utils.GSM;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 *
 * @author pduonghoa
 */
public class GSMController{
    private static BufferedReader sc = new BufferedReader(
            new InputStreamReader(System.in));

    public static void gsmAccess(GSM gsm) {
        System.out.println(gsm);
        int chose = 0;
        while (chose!=5) {
            System.out.println("Command menu ");
            System.out.println("1. Call history");
            System.out.println("2. add call");
            System.out.println("3. remove longest call");
            System.out.println("4. price check");
            System.out.println("5. back!!!");
            System.out.print("Select command: ");
            try {
                chose = Integer.parseInt(sc.readLine());
            } catch (NumberFormatException ex){
                System.out.println(ex);
            } catch (IOException ex){
                System.out.println(ex);
            }
            switch (chose) {
                case 1:
                    viewCallHistory(gsm);
                    break;
                case 2:
                    addCall(gsm);
                    break;
                case 3:
                    removeLongestCall(gsm);
                    break;
                case 4:
                    priceCheck(gsm);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("command not found!!!");
                    break;
            }
        }
    }
    public static void viewCallHistory(GSM gsm){
        System.out.println("=============call history=============");
        List<Call> callHistory = gsm.getCallHistory();
        callHistory.forEach((call)->{
            System.out.print(call);
        });
        System.out.println("======================================");
    }

    public static void addCall(GSM gsm){
        System.out.println("=============Add cally=============");
        try {
            System.out.print("Date: ");
            String date = sc.readLine();
            System.out.print("Time: ");
            String time = sc.readLine();
            System.out.print("Duration: ");
            Float duration = Float.parseFloat(sc.readLine());
            System.out.print("Dialed number: ");
            String dialed = sc.readLine();

            Call call;
            call = new Call(date, time, duration, dialed);
            System.out.println(call);
            gsm.createCall(call);
        }
        catch (NumberFormatException ex){
            System.out.println(ex);
        } catch (IOException ex){
            System.out.println(ex);
        } finally {
            System.out.println("======================================");
        }
    }

    public static void removeLongestCall(GSM gsm){
        System.out.println("=============Remove Call=============");
        Call result = gsm.removeLongestCall();
        if (result==null) {
            System.out.println("No call history");
        }
        else{
            System.out.printf("Call removed: %s\n", result);
        }
        System.out.println("======================================");
    }

    public static void priceCheck(GSM gsm){
        System.out.println("===========Total call price===========");
        float timeCall = gsm.totalCallTime();
        System.out.printf("Total call time: %.2f\nPrice: %.2f\nTotal: %.2f\n",
                timeCall, GSM.getCallPrice(), timeCall * GSM.getCallPrice());
        System.out.println("======================================");
    }

    public static GSM addGSM(String model, String mft, float price, String owner, Battery bat, Display dis){
        return new GSM(model, mft, price, owner, bat, dis);
    }

}
