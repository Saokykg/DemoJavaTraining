package com.tma.controller;

import com.tma.utils.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class MainController {
    private static BufferedReader sc = new BufferedReader(
            new InputStreamReader(System.in));

    public static void mainmenu(List<GSM> gsm) {

        int chose = 0;
        while (chose!=5) {
            System.out.println("Command menu ");
            System.out.println("1. add gsm");
            System.out.println("2. remove gsm");
            System.out.println("3. show list gsm");
            System.out.println("4. select gsm by id");
            System.out.println("5. exit!!!");
            System.out.print("Select command: ");
            try {
                chose = Integer.parseInt(sc.readLine());
            } catch (NumberFormatException ex){
                System.out.println(ex);
            } catch (IOException ex){
                System.out.println(ex);
            }

            switch (chose) {
                case 1:
                    addGSM(gsm);
                    break;
                case 2:
                    removeGSM(gsm);
                    break;
                case 3:
                    list(gsm);
                    break;
                case 4:
                    select(gsm);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("command not found!!!");
                    break;
            }
        }
    }
    public static void addGSM(List<GSM> gsm){
        try {
            System.out.println("==========Input gsm infomation==========");
            System.out.println("Model: ");
            String model = sc.readLine();
            System.out.println("Manufacturer: ");
            String manufacturer = sc.readLine();
            System.out.println("Price: ");
            float price = Float.parseFloat(sc.readLine());
            System.out.println("Owner: ");
            String owner = sc.readLine();

            System.out.println();

            System.out.println("Battery info: ");
            System.out.println("Model battery: ");
            String batModel = sc.readLine();
            System.out.println("Hours idle: ");
            float houridl = Float.parseFloat(sc.readLine());
            System.out.println("Hours talk: ");
            float hourtalk = Float.parseFloat(sc.readLine());

            System.out.println("Chose battery type: ");

            int od = 1;
            for (EnumShare.batteryType bt : EnumShare.batteryType.values()) {
                System.out.printf("%d, %s \n", od++, bt);
            }
            System.out.printf("%d, %s \n", 4, "no info");
            int c = -1;
            while (c < 1 || c > od + 1) {
                c = Integer.parseInt(sc.readLine());
            }
            Battery bat;
            if (od + 1 == c)
                bat = new Battery(batModel, houridl, hourtalk, null);
            else
                bat = new Battery(batModel, houridl, hourtalk, EnumShare.get(od));

            System.out.println();
            System.out.println("Display info: ");
            System.out.println("Size: ");
            int size = Integer.parseInt(sc.readLine());
            System.out.println("Colors: ");
            int colors = Integer.parseInt(sc.readLine());
            Display dis = new Display(size, colors);
            GSM addingGSM = GSMController.addGSM(model, manufacturer, price, owner, bat, dis);
            System.out.println(addingGSM);
            gsm.add(addingGSM);
        } catch (NumberFormatException ex){
            System.out.println(ex);
        } catch (IOException ex){
            System.out.println(ex);
        } finally {
            System.out.println("========================================");
        }

    }

    public static void removeGSM(List<GSM> gsm){
        System.out.println("=============Remove gsm================");
        GSM deteleObj = choseGSM(gsm);
        try {
            gsm.remove(deteleObj);
        } catch (NullPointerException ex){
            System.out.println(ex);
        } finally {
            System.out.println("======================================");
        }
    }

    public static void list(List<GSM> gsm){
        System.out.println("===============List gsm=================");
        gsm.forEach((obj) -> {
            System.out.println(obj);
            System.out.println("---------------------");
        });
        System.out.println("====================================");
    }

    public static void select(List<GSM> gsm){
        GSMController.gsmAccess(choseGSM(gsm));
    }

    public static GSM choseGSM(List<GSM> gsm) {
        BufferedReader sc = new BufferedReader(
                new InputStreamReader(System.in));
        gsm.forEach((obj) -> {
            System.out.printf("%d: %s - %s \n", obj.getId(), obj.getModel(), obj.getManufacturer());
        });
        int id = 0;
        System.out.print("Enter gsm id: ");
        while (id < 1 || id > gsm.size()) {
            try {
                id = Integer.parseInt(sc.readLine());
            } catch (NumberFormatException ex){
                System.out.println(ex);
            } catch (IOException ex){
                System.out.println(ex);
            }
        }
        return gsm.get(id-1);
    }
}
